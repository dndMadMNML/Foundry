Hooks.once('init', function() {
  game.settings.register("mmm", "applyOnCritSave", {
    name: "При провале испытания",
    hint: "Запрос на Травму, при провале испытания.",
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register("mmm", "applyOnCrit", {
    name: "При Критическом попадании",
    hint: "Запрос на Травму, при получении критического удара.",
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register("mmm", "applyOnDamage", {
    name: "При массивном уроне",
    hint: "Запрос на Травму, когда полученный урон превышает половину от максимального ПЗ актера.",
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register("mmm", "applyOnDown", {
    name: "ПЗ на нуле",
    hint: "Запрос на Травму, когда урон уменьшает ПЗ актера до 0.",
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register("mmm", "nonMidiAutomation", {
    name: "Ручное изменение ПЗ",
    hint: "Обеспечивает некоторую автоматизацию в случае, если вы не используете midi-qol или вручную изменяете ПЗ. Работают только автоматические функции 'ПЗ на нуле' и 'При массивном уроне'. Поскольку система не знает, какой тип урона вызвал травму, игроку будет предложен выбор таблицы травм",
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
  });

  game.settings.register("mmm", "triggerNpc", {
    name: "Применять травмы на НЦП",
    hint: "Включает автоматизацию для актёров, не принадлежащих игрокам.",
    scope: "world",
    config: true,
    type: Boolean,
    default: false,
  });

  game.settings.register("mmm", "selfdestruct", {
    name: "Уничтожение предметов Травм",
    hint: "Если временя активного эффекта травмы закончилось, удалить предмет с травмой. (требуется DAE/MidiQoL)",
    scope: "world",
    config: true,
    type: Boolean,
    default: false,
  });

});

Hooks.once('ready', async function() {

});

Hooks.on("chatMessage", (ChatLog, content) => {
    if (content.toLowerCase().startsWith("/mmmm")) {
      const data = content.replace("/mmmm", "").trim();
      if(data){
        MaxwelMaliciousMaladies.rollTable(data);
      }else{
        MaxwelMaliciousMaladies.displayDialog();
      }

      return false;
    }
  });

Hooks.on("renderChatMessage", (message, html)=>{
    if(!game.user.isGM || !message?.flavor?.includes("[MMMM]")) return;
    const subTables = ["Scar Chart", "Small Appendage Table", "Large Limb Table"];
    for(let t of subTables){
      if(message?.flavor?.includes(t)) return;
    }
    const button = $(`<a title="Применить травму" style="margin-right: 0.3rem;color: red;" class="button"><i class="fas fa-viruses"></i></a>`)
    html.find(".result-text").prepend(button)
    button.on("click", async (e)=>{
        e.preventDefault();
        let actor = game.scenes.get(message?.speaker?.scene)?.tokens?.get(message?.speaker?.token)?.actor;
        actor = actor ?? (game.actors.get(message?.speaker?.actor) ?? _token?.actor);
        if(!actor) return ui.notifications.error("Нет выбраного токена или не найден актер!");
        const content = $(message.content)
        const imgsrc = content.find("img").attr("src");
        const description = content.find(".result-text").html();
        const duration = MaxwelMaliciousMaladies.inferDuration(content.find(".result-text").text());
        const title = "Травма - " + content.find("strong").first().text();
        const itemData = {
            name: title,
            img: imgsrc,
            type: "feat",
            "system.description.value": description,
            flags: {
              mmm: 
              {
                lingeringInjury: true
              }
            },
            "effects": [
              {
                icon: imgsrc,
                label: title,
                transfer: true,
                changes: [
                  {
                    "key": "flags.dae.deleteOrigin",
                    "value":  game.settings.get("mmm", "selfdestruct") ? 1 : "",
                    "mode": 2,
                    "priority": 0
                  }
                ],
                duration: {
                  seconds: title.includes("(") ? null : duration || 9999999999,
                },
                flags: {
                  mmm: 
                  {
                    lingeringInjury: true
                  },
                  "dfreds-convenient-effects": {
                    "description": description,
                  },
                },
              }
            ],
        }
        actor.createEmbeddedDocuments("Item", [itemData]);
        ui.notifications.notify(`Добавлен ${title} к ${actor.name}`)
    });
});

let MaxwelMaliciousMaladiesSocket;

Hooks.once("socketlib.ready", () => {
  MaxwelMaliciousMaladiesSocket = socketlib.registerModule("mmm");
  MaxwelMaliciousMaladiesSocket.register("requestRoll", MaxwelMaliciousMaladies.requestRoll);
});